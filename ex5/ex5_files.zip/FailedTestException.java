
public class FailedTestException extends Exception {
	public FailedTestException(String message) {
		super(message);
	}

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
}
